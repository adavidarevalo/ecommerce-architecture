import boto3
import os

def handler(event, context):
    asg_client = boto3.client('autoscaling')
    asg_name = os.environ['ASG_NAME']
    
    # Start instance refresh for Blue/Green deployment
    response = asg_client.start_instance_refresh(
        AutoScalingGroupName=asg_name,
        Strategy='Rolling',
        Preferences={
            'MinHealthyPercentage': 50,
            'InstanceWarmup': 300
        }
    )
    
    return {
        'statusCode': 200,
        'body': f'Instance refresh started: {response["InstanceRefreshId"]}'
    }
